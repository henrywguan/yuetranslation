# Yue — English ↔ Cantonese

Face-to-face live translator PWA with WordPress freemium entitlements for Bluehost launch.

**Stack (launch):** Azure Speech (`zh-HK` STT/TTS) + OpenAI (colloquial 粵語) + WP plugin metering.

## Apps

- `apps/web` — React/Vite PWA (solo, face-to-face, text + Jyutping)
- `apps/api` — Express cloud proxy for local testing
- `wordpress/yue-translator` — Bluehost plugin (REST + entitlements + shortcode)

## Quick start (local)

```bash
cp apps/api/.env.example apps/api/.env
npm install --prefix apps/api
npm install --prefix apps/web
npm run dev:api
npm run dev:web
```

## WordPress package

```bash
npm run build:web:wp
```

Upload `wordpress/yue-translator` and follow [docs/bluehost-launch.md](docs/bluehost-launch.md).

Entitlement design: [docs/entitlements.md](docs/entitlements.md).
